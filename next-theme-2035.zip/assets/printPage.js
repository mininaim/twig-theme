const printThisPage = () => {
  window.print();
};
